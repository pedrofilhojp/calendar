# Agenda e Calendário de Compromissos para Aulas de Kubernetes

Aplicação didática em microsserviços com autenticação JWT, PostgreSQL, RabbitMQ, worker de notificações por e-mail, Mailpit e frontend estático. O objetivo é permitir que alunos observem Deployments, StatefulSets, Services, Ingress, Secrets, ConfigMaps, probes, filas e HPA em um cenário funcional.

## Estrutura

```text
backend/   API FastAPI com JWT, PostgreSQL e publicação no RabbitMQ
worker/    Consumer Python com pika e envio SMTP para Mailpit
frontend/  HTML, CSS e JavaScript vanilla servidos por Nginx
k8s/       Manifestos Kubernetes numerados para aplicação em ordem
```

## Pré-requisitos

- Docker
- kubectl
- Cluster Kubernetes local, como Minikube, Kind ou Docker Desktop
- NGINX Ingress Controller instalado
- Metrics Server instalado para o HPA

## Teste local com Docker Compose

Para subir toda a aplicação sem Kubernetes:

```bash
docker compose up --build
```

Se sua máquina usa o binário legado, substitua `docker compose` por `docker-compose`.

Acesse:

- Frontend: `http://localhost:8080`
- API direta: `http://localhost:8000/docs`
- API via frontend/Nginx: `http://localhost:8080/api/docs`
- Mailpit: `http://localhost:8025/emails/`
- RabbitMQ Management: `http://localhost:15672` com usuário `agenda_user` e senha `agenda_password`

Comandos úteis:

```bash
docker compose ps
docker compose logs -f backend
docker compose logs -f worker
docker compose up --build --force-recreate --no-deps frontend
docker compose down
docker compose down -v
```

Use `docker compose down -v` quando quiser apagar também os dados persistidos do PostgreSQL local.

Se estiver usando o `docker-compose` legado (`docker-compose==1.29.x`) e aparecer `KeyError: 'ContainerConfig'`, o problema é do Compose v1 ao recriar containers antigos com metadados de imagens novas. Para rebuildar somente o frontend, use:

```bash
docker-compose up --build --force-recreate --no-deps frontend
```

Para recriar a stack inteira, limpe os containers antigos antes:

```bash
docker-compose down --remove-orphans
docker rm -f agenda-postgres agenda-rabbitmq agenda-mailpit agenda-backend agenda-worker agenda-frontend
docker-compose up --build
```

O comando `docker rm -f` pode informar que algum container não existe; nesse caso, siga normalmente.

## Build das imagens

Com Minikube:

```bash
eval $(minikube docker-env)
docker build -t agenda-backend:1.0.0 ./backend
docker build -t agenda-worker:1.0.0 ./worker
docker build -t agenda-frontend:1.0.0 ./frontend
```

Com Kind:

```bash
docker build -t agenda-backend:1.0.0 ./backend
docker build -t agenda-worker:1.0.0 ./worker
docker build -t agenda-frontend:1.0.0 ./frontend
kind load docker-image agenda-backend:1.0.0
kind load docker-image agenda-worker:1.0.0
kind load docker-image agenda-frontend:1.0.0
```

## Instalação no Kubernetes

```bash
kubectl apply -f k8s/
kubectl get pods -n agenda -w
```

Verifique Services, Deployments e StatefulSet:

```bash
kubectl get all -n agenda
kubectl get pvc -n agenda
kubectl get ingress -n agenda
```

Para usar o Ingress local, aponte `agenda.local` para o IP do cluster:

```bash
minikube ip
```

Adicione no `/etc/hosts`:

```text
IP_DO_CLUSTER agenda.local
```

Acesse:

- Frontend: `http://agenda.local/`
- API: `http://agenda.local/api/docs`
- Mailpit: `http://agenda.local/emails/`

Alternativa sem Ingress:

```bash
kubectl port-forward -n agenda svc/frontend 8080:80
```

Nesse modo, abra `http://localhost:8080`. O Nginx do frontend encaminha `/api` para o backend e `/emails` para o Mailpit dentro do cluster.

## Fluxo de uso

1. Abra o frontend.
2. Cadastre um usuário com e-mail e senha de pelo menos 8 caracteres.
3. Crie um compromisso com data, prioridade e convidados separados por vírgula.
4. Alterne entre calendário mensal e anual para visualizar a distribuição dos compromissos.
5. Edite ou exclua compromissos pelo painel de próximos eventos.
6. Ajuste as cores das prioridades no painel lateral; a preferência fica salva no navegador.
7. Abra o Mailpit para inspecionar os e-mails HTML capturados.

## Endpoints principais

- `POST /auth/register`: cadastro com retorno de token JWT.
- `POST /auth/login`: autenticação com retorno de token JWT.
- `GET /appointments`: lista os compromissos do usuário autenticado.
- `POST /appointments`: cria compromisso e publica mensagem no RabbitMQ.
- `PUT /appointments/{id}`: edita um compromisso existente.
- `DELETE /appointments/{id}`: cancela um compromisso.
- `GET /healthz/live` e `GET /healthz/ready`: probes para Kubernetes.

## Depuração

Logs da API:

```bash
kubectl logs -n agenda deploy/backend
kubectl logs -n agenda deploy/backend --follow
```

Logs do worker:

```bash
kubectl logs -n agenda deploy/worker --follow
```

Eventos e detalhes de um Pod:

```bash
kubectl describe pod -n agenda -l app=backend
kubectl describe pod -n agenda -l app=postgres
```

Entrar no PostgreSQL:

```bash
kubectl exec -it -n agenda statefulset/postgres -- psql -U agenda_user -d agenda
```

Conferir mensagens e filas no RabbitMQ:

```bash
kubectl port-forward -n agenda svc/rabbitmq 15672:15672
```

Depois acesse `http://localhost:15672` com usuário `agenda_user` e senha `agenda_password`.

Checar probes diretamente:

```bash
kubectl port-forward -n agenda svc/backend 8000:8000
curl http://localhost:8000/healthz/live
curl http://localhost:8000/healthz/ready
```

## Dinâmicas para aula

Forçar queda do banco e observar readiness da API:

```bash
kubectl scale statefulset/postgres -n agenda --replicas=0
kubectl get pods -n agenda -w
kubectl describe pod -n agenda -l app=backend
```

Restaurar o banco:

```bash
kubectl scale statefulset/postgres -n agenda --replicas=1
```

Escalar workers para demonstrar consumo independente:

```bash
kubectl scale deployment/worker -n agenda --replicas=3
kubectl get pods -n agenda -l app=worker
```

Simular falha do RabbitMQ e observar backend/worker:

```bash
kubectl scale deployment/rabbitmq -n agenda --replicas=0
kubectl logs -n agenda deploy/worker --follow
```

Restaurar RabbitMQ:

```bash
kubectl scale deployment/rabbitmq -n agenda --replicas=1
```

Estressar a API para observar o HPA:

```bash
kubectl run -n agenda load-generator --rm -it --image=busybox:1.36 -- /bin/sh
```

Dentro do shell:

```sh
while true; do wget -q -O- http://backend:8000/healthz/live >/dev/null; done
```

Em outro terminal:

```bash
kubectl get hpa -n agenda -w
kubectl top pods -n agenda
```

Remover tudo:

```bash
kubectl delete -f k8s/
```

Para apagar também os dados persistidos:

```bash
kubectl delete pvc -n agenda -l app=postgres
```

## Variáveis de ambiente usadas

Backend:

- `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`
- `RABBITMQ_HOST`, `RABBITMQ_USER`, `RABBITMQ_PASSWORD`
- `JWT_SECRET`

Worker:

- `RABBITMQ_HOST`, `RABBITMQ_USER`, `RABBITMQ_PASSWORD`
- `SMTP_HOST`, `SMTP_PORT`

Se alguma variável obrigatória estiver ausente, o processo falha no startup com log explícito para facilitar demonstrações de configuração.
