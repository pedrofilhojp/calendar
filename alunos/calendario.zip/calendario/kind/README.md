# Cluster Kind para a Agenda

Este diretório contém uma configuração do Kind com 1 control-plane e 2 workers. A porta `8080` do host é mapeada para a porta `80` do cluster, permitindo acessar o NGINX Ingress em `http://localhost:8080`.

## Pré-requisitos

- Docker
- Kind
- kubectl

## Criar o cluster

Execute a partir da raiz do projeto:

```bash
kind create cluster --config kind/kind-config.yaml
kubectl cluster-info --context kind-cluster-agenda
kubectl get nodes
```

Os dois workers recebem labels para facilitar aulas sobre seleção e agendamento de pods:

- `node/type=spot`
- `node/type=on-demand`

Verifique com:

```bash
kubectl get nodes --show-labels
```

Se o cluster já existir, recrie-o para aplicar as labels do arquivo:

```bash
kind delete cluster --name cluster-agenda
kind create cluster --config kind/kind-config.yaml
```

Ou aplique labels manualmente nos nodes existentes:

```bash
kubectl label node cluster-agenda-worker node/type=spot --overwrite
kubectl label node cluster-agenda-worker2 node/type=on-demand --overwrite
```

## Instalar o NGINX Ingress Controller

```bash
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/kind/deploy.yaml
```

Aguarde o controller ficar pronto:

```bash
kubectl wait --namespace ingress-nginx \
  --for=condition=ready pod \
  --selector=app.kubernetes.io/component=controller \
  --timeout=180s
```

## Construir e carregar as imagens

Execute na raiz do projeto:

```bash
docker build -t agenda-backend:1.0.0 ./backend
docker build -t agenda-worker:1.0.0 ./worker
docker build -t agenda-frontend:1.0.0 ./frontend

kind load docker-image agenda-backend:1.0.0 --name cluster-agenda
kind load docker-image agenda-worker:1.0.0 --name cluster-agenda
kind load docker-image agenda-frontend:1.0.0 --name cluster-agenda
```

## Aplicar a aplicação

```bash
kubectl apply -f k8s/
kubectl get pods -n agenda -w
```

Quando todos os pods estiverem `Running` ou `Ready`, acesse:

- Frontend: `http://localhost:8080/`
- API: `http://localhost:8080/api/docs`
- Mailpit: `http://localhost:8080/emails/`

## Instalar Metrics Server para testar o HPA

O HPA precisa de métricas de CPU. Para ambiente local com Kind:

```bash
kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml
kubectl patch deployment metrics-server -n kube-system --type=json \
  -p='[{"op":"add","path":"/spec/template/spec/containers/0/args/-","value":"--kubelet-insecure-tls"}]'
```

Verifique:

```bash
kubectl top nodes
kubectl get hpa -n agenda
```

## Comandos úteis

```bash
kubectl get all -n agenda
kubectl logs -n agenda deploy/backend --follow
kubectl logs -n agenda deploy/worker --follow
kubectl describe ingress -n agenda
```

## Remover o cluster

```bash
kind delete cluster --name cluster-agenda
```
